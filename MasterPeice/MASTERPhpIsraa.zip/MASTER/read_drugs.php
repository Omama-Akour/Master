<?php
header("Access-Control-Allow-Origin:* ");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
include 'connect.php';

// ----------------------------------------------------------------------------------////
// ----------------------------GET METHOD TO SELECT ALL THE drugS-----------------
// ----------------------------------------------------------------------------------

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    try {
        $query = "SELECT * FROM drugs;";
        $result = $mysqli->query($query);

        if ($result) {
            $data = array();
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            header("Content-Type: application/json");
            echo json_encode($data);
        } else {
            echo json_encode(['message' => 'Error executing query']);
        }
    } catch (Exception $e) {
        die("Error: " . $e->getMessage());
    }
}

// ----------------------------------------------------------------------------------
// ----------------------------POST METHOD TO SELECT BY drug ID-------------------
// ----------------------------------------------------------------------------------

elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $json_data = file_get_contents("php://input");
        $data = json_decode($json_data, true);

        $query = "SELECT * FROM drugs WHERE drug_id = ? ";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('i', $data['id']);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();

        if ($result) {
            echo json_encode($result);
        } else {
            echo json_encode(['message' => 'No record found']);
        }

    } catch (Exception $e) {
        die("Error: " . $e->getMessage());
    }
} else {
    echo json_encode(['message' => 'incorrect request method']);
}
?>
