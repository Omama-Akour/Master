<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
include 'connect.php';

// ----------------------------------------------------------------------------------
// ----------------------------DELETE METHOD TO REMOVE A PRODUCT FROM CART------------
// ------------------------------------FOR A SPECIFIC USER AND PRODUCT-----------------
// ----------------------------------------------------------------------------------

if ($_SERVER["REQUEST_METHOD"] == "DELETE" || $_SERVER["REQUEST_METHOD"] == "POST") {
    
    try {
        $json_data = file_get_contents("php://input");
        $data = json_decode($json_data, true);

        // Check if user_id and drug_id keys exist in $data array
        if (!isset($data['user_id']) || !isset($data['drug_id'])) {
            echo json_encode(['message' => 'Missing user_id or drug_id in the request.']);
            exit;
        }

        $user_id = $data['user_id'];
        $drug_id = $data['drug_id'];
        $skincare_id = isset($data['skincare_id']) ? $data['skincare_id'] : null;

        // Check if $pdo is defined in your connect.php file
        if (!isset($pdo)) {
            echo json_encode(['message' => 'Database connection is not established.']);
            exit;
        }

        // Choose the appropriate column based on the presence of $skincare_id
        $column = ($skincare_id !== null) ? 'skincare_id' : 'drug_id';
        $value = ($skincare_id !== null) ? $skincare_id : $drug_id;

        $query = "DELETE FROM cart WHERE user_id = ? AND $column = ?";
        $stmt = $pdo->prepare($query);

        // Check if the prepare statement was successful
        if (!$stmt) {
            echo json_encode(['message' => 'Error preparing the delete statement.']);
            exit;
        }

        $stmt->execute([$user_id, $value]);

        // Check if any rows were affected to determine if the deletion was successful
        $rowCount = $stmt->rowCount();

        if ($rowCount > 0) {
            echo json_encode(['message' => 'Product removed from the cart successfully.']);
        } else {
            echo json_encode(['message' => 'Product not found in the cart for the specified user.']);
        }

    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
?>
