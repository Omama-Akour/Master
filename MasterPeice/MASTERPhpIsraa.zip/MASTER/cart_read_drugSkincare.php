<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
include 'connect.php';

// ----------------------------------------------------------------------------------
// ----------------------------GET METHOD TO SELECT ALL THE CART PRODUCTS------------
// ------------------------------------FOR EVERY USER--------------------------------
// ----------------------------------------------------------------------------------

if ($_SERVER["REQUEST_METHOD"] == "GET" || $_SERVER["REQUEST_METHOD"] == "POST") {
    
    try {
        $json_data = file_get_contents("php://input");
        $data = json_decode($json_data, true);

        // Check if 'id' key exists in $data array
        if (!isset($data['id'])) {
            echo json_encode(['message' => 'Missing user_id in the request.']);
            exit;
        }

        $user_id = $data['id']; // Assuming 'id' is an integer, adjust accordingly if it's not.

        $query = "SELECT cart.*, skincare.skincare_id, users.user_id, drugs.drug_id, drugs.price AS drug_price, skincare.price AS skincare_price
                  FROM cart
                  INNER JOIN skincare ON cart.skincare_id = skincare.skincare_id
                  INNER JOIN users ON cart.user_id = users.user_id
                  INNER JOIN drugs ON cart.drug_id = drugs.drug_id 
                  WHERE cart.user_id = ? LIMIT 0, 25"; 

        // Assuming you have already defined $mysqli in your 'connect.php' file
        $stmt = $mysqli->prepare($query);

        // Check if the prepare statement was successful
        if (!$stmt) {
            echo json_encode(['message' => 'Error preparing the statement.']);
            exit;
        }

        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        $rows = array();
        while ($row = $result->fetch_assoc()) {
            // Calculate total_price based on drug and skincare prices
            $total_price = ($row['drug_price'] + $row['skincare_price']) * $row['quantity'];
            $row['total_price'] = $total_price;

            $rows[] = $row;
        }

        if ($rows) {
            echo json_encode($rows);
        } else {
            echo json_encode(['message' => 'No products found in the cart for the specified user.']);
        }

        $stmt->close();

    } catch (Exception $e) {
        die("Error: " . $e->getMessage());
    }
}
?>
