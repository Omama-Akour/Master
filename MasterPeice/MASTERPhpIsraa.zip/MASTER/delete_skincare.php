<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// ----------------------------------------------------------
// ------------------DELETE FROM skincareS -------------------
// --------------------BY SENDING ID : JSON -----------------
// ----------------------------------------------------------
// {
//   "id": 1
// }
// ----------------------------------------------------------
// ----------------------------------------------------------
// ----------------------------------------------------------

include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    $json_data = file_get_contents('php://input');
    $data = json_decode($json_data, true);

    if (!empty($data)) {
        $query = 'DELETE FROM `skincare` WHERE skincare_id=?;';
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('i', $data['id']);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo json_encode(['message' => 'Delete successful']);
        } else {
            echo json_encode(['message' => 'No record found for the given ID']);
        }
        
        $stmt->close();
    } else {
        echo json_encode(['message' => 'Invalid JSON data']);
    }
} else {
    echo json_encode(['message' => 'Incorrect request method']);
}
?>
