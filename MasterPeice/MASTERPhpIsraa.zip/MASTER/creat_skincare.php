<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
include 'connect.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $json_data = file_get_contents('php://input');
    $data = json_decode($json_data, true);
 
    if (!empty($data)) {
        $query = 'INSERT INTO skincare (image,name,description,skin_type,price,created_at) VALUES (?,?,?,?,?,NOW());';

        $stmt = $pdo->prepare($query);

        $stmt->execute([$data['image'], $data['name'], $data['description'],$data['skin_type'], $data['price'],  $data['category_id']]);

        if ($stmt) {
            echo json_encode(['message' => 'skincare inserted successfully']);
        } else {
            echo json_encode(['message' => 'Failed to insert the skincare']);
        }
    } else {
        echo json_encode(['message' => 'No data provided for insertion']);
    }
} else {
    echo json_encode(['message' => 'Incorrect request method']);
}









?>
