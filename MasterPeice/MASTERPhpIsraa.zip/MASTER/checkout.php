<?php

include 'connect.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $json_data = file_get_contents('php://input');
    $data = json_decode($json_data, true);
    
    if ($data === null) {
        echo "Invalid JSON data.";
    }
    
    $user_id = isset($data['user_id']) ? $data['user_id'] : null;

    $sql = "SELECT SUM(IF(drugs.price > 0, drugs.price, 0) + IF(skincare.price > 0, skincare.price, 0)) * cart.quantity as total 
            FROM cart
            INNER JOIN skincare ON cart.skincare_id = skincare.skincare_id
            INNER JOIN users ON cart.user_id = users.user_id
            INNER JOIN drugs ON cart.drug_id = drugs.drug_id 
            WHERE cart.user_id = '$user_id'";

    $result = $mysqli->query($sql);
    $total = 0;
    $cart = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $total = $row["total"];
        }

        $sql = "SELECT cart.*, drugs.drug_id, skincare.skincare_id
                FROM cart
                LEFT JOIN drugs ON cart.drug_id = drugs.drug_id
                LEFT JOIN skincare ON cart.skincare_id = skincare.skincare_id
                WHERE cart.user_id = '$user_id'";
        $result = $mysqli->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $cart[] = $row;
            }
        }
        
        $sql = "DELETE FROM cart WHERE user_id = '$user_id' ";
        $result = $mysqli->query($sql);

    } else {
        die("Script terminated due to EMPTY CART.");
    }

    $orders = array();

    try {
        $sql = "INSERT INTO `orders`(`user_id`, `total_price`) VALUES (?, ?)";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("ii", $user_id, $total);

        // Execute the statement
        if ($stmt->execute()) {
            // Success
        } else {
            // Error handling
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } catch (Exception $e) {
        // Handle the exception here, for example, log the error, display an error message, or take appropriate action.
        echo "Error: " . $e->getMessage();
    }
} else {
    // This is not a POST request
    echo "This endpoint only accepts POST requests.";
}
?>
